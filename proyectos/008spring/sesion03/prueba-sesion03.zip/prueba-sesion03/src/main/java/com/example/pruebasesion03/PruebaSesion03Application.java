package com.example.pruebasesion03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaSesion03Application {

	public static void main(String[] args) {
		SpringApplication.run(PruebaSesion03Application.class, args);
	}

}
