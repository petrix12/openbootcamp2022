package com.example.sesion07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sesion07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
