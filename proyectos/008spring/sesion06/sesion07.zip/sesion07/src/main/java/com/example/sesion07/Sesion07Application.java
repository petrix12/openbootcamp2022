package com.example.sesion07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sesion07Application {

	public static void main(String[] args) {
		SpringApplication.run(Sesion07Application.class, args);
	}

}
