package com.company;

public class Main {

    public static void main(String[] args) {
        // Parte I
        System.out.println(suma(3, 7, 12));

        // Parte II
        Coche miCoche = new Coche();
        miCoche.AddPuerta();
        System.out.println("Puertas de mi coche: " + miCoche.puertas);
    }

    // Parte I
    public static int suma(int a, int b, int c) {
        return a + b + c;
    }
}

// Parte II
class Coche {
   public int puertas = 0;

   public void AddPuerta() {
       this.puertas++;
   }
}