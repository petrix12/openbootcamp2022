package com.company;

public class Main {

    public static void main(String[] args) {
        Persona persona = new Persona();

        persona.setEdad(50);
        persona.setNombre("Pedro");
        persona.setTelefono("0035-218-254.44.89");

        int edad = persona.getEdad();
        String nombre = persona.getNombre();
        String telefono = persona.getTelefono();

        System.out.println(nombre + " tiene " + edad + " años y su número es " + telefono);
    }
}

class Persona {
    private int edad;
    private String nombre;
    private String telefono;

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getEdad() {
        return this.edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTelefono() {
        return this.telefono;
    }
}

